const express = require("express");
const router = express.Router();
const controller = require("../controllers/scheduleHistoryController");

// FIXED ROUTE ORDER (static routes first)
router.post("/restore/:versionId", controller.restoreVersion);

// Get versions list
router.get("/:id/versions", controller.getVersions);

// Save version
router.post("/:id/save", controller.saveVersion);

module.exports = router;
