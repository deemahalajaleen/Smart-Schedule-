// backend/controllers/scheduleHistoryController.js

const sql = require("../config/db");
const jsondiffpatch = require("jsondiffpatch").create({
  arrays: { detectMove: false }, // faster
  textDiff: { minLength: 200 }, // avoid heavy text diff
});

// ------------------------------------------------------
// Helper: Get CLEAN schedule snapshot (no joins, no extras)
// ------------------------------------------------------
async function getFullScheduleObject(scheduleId) {
  const schedule = await sql`
    SELECT id, title, status, level_id, group_id, created_at, updated_at, created_by, approved_by
    FROM schedule WHERE id = ${scheduleId}
  `;

  const sections = await sql`
    SELECT id, course_id, faculty_id, room_id, section_code,
           start_time, end_time, day_of_week, type, section_group
    FROM sections
    WHERE schedule_id = ${scheduleId}
  `;

  return {
    schedule: schedule[0] || null,
    sections,
  };
}

// ------------------------------------------------------
// Save version
// ------------------------------------------------------
exports.saveVersion = async (req, res) => {
  try {
    const scheduleId = req.params.id;
    const userId =
      req.user?.id ||
      req.body.created_by || // allow manual sent user
      req.headers["x-user-id"] ||
      null;

    // Get new snapshot
    const newSnap = await getFullScheduleObject(scheduleId);

    // Get last version
    const last = await sql`
      SELECT patch, version
      FROM schedule_history
      WHERE schedule_id = ${scheduleId}
      ORDER BY version DESC
      LIMIT 1
    `;

    let patch;

    if (last.length === 0) {
      // first snapshot → store full
      patch = { full: newSnap };
    } else {
      let prevSnap;

      if (last[0].patch.full) {
        prevSnap = last[0].patch.full;
      } else {
        prevSnap = await rebuildSnapshot(scheduleId);
      }

      // generate diff
      const diff = jsondiffpatch.diff(prevSnap, newSnap);

      patch = diff || {}; // empty diff allowed
    }

    // compute next version
    const ver = await sql`
      SELECT COALESCE(MAX(version), 0) + 1 AS v
      FROM schedule_history
      WHERE schedule_id = ${scheduleId}
    `;

    const nextV = ver[0].v;

    // save version
    await sql`
      INSERT INTO schedule_history (schedule_id, version, patch, created_by)
      VALUES (${scheduleId}, ${nextV}, ${patch}, ${userId})
    `;

    res.json({
      message: "Version saved successfully",
      version: nextV,
    });
  } catch (err) {
    console.error("Save version error:", err);
    res.status(500).json({ error: "Failed to save version" });
  }
};

// ------------------------------------------------------
// Rebuild snapshot
// ------------------------------------------------------
async function rebuildSnapshot(scheduleId) {
  const rows = await sql`
    SELECT patch, version
    FROM schedule_history
    WHERE schedule_id = ${scheduleId}
    ORDER BY version ASC
  `;

  let snap;

  // version 1 must be full
  if (rows[0].patch.full) {
    snap = rows[0].patch.full;
  } else {
    throw new Error("Missing full snapshot at version 1");
  }

  // apply diffs
  for (let i = 1; i < rows.length; i++) {
    const p = rows[i].patch;
    if (p.full) snap = p.full;
    else jsondiffpatch.patch(snap, p);
  }

  return snap;
}

// ------------------------------------------------------
// Restore selected version
// ------------------------------------------------------
exports.restoreVersion = async (req, res) => {
  try {
    const versionId = req.params.versionId;

    const row = await sql`
      SELECT schedule_id, version
      FROM schedule_history
      WHERE id = ${versionId}
    `;

    if (row.length === 0)
      return res.status(404).json({ error: "Version not found" });

    const { schedule_id, version } = row[0];

    // load all versions
    const all = await sql`
      SELECT patch, version
      FROM schedule_history
      WHERE schedule_id = ${schedule_id}
      ORDER BY version ASC
    `;

    let snap;

    if (all[0].patch.full) snap = all[0].patch.full;
    else throw new Error("Missing full snapshot");

    // apply diffs up to target version
    for (let i = 1; i < version; i++) {
      const p = all[i].patch;
      if (p.full) snap = p.full;
      else jsondiffpatch.patch(snap, p);
    }

    // apply restored snapshot
    const s = snap.schedule;

    await sql`
      UPDATE schedule
      SET title=${s.title}, status=${s.status},
          level_id=${s.level_id}, group_id=${s.group_id},
          updated_at=NOW()
      WHERE id=${schedule_id}
    `;

    await sql`DELETE FROM sections WHERE schedule_id=${schedule_id}`;

    for (const sec of snap.sections) {
      await sql`
        INSERT INTO sections (
          schedule_id, course_id, faculty_id, room_id,
          section_code, start_time, end_time,
          day_of_week, type, section_group
        )
        VALUES (
          ${schedule_id}, ${sec.course_id}, ${sec.faculty_id}, ${sec.room_id},
          ${sec.section_code}, ${sec.start_time}, ${sec.end_time},
          ${sec.day_of_week}, ${sec.type}, ${sec.section_group}
        )
      `;
    }

    res.json({ message: "Version restored" });
  } catch (err) {
    console.error("Restore version error:", err);
    res.status(500).json({ error: "Failed to restore version" });
  }
};

// ------------------------------------------------------
// Get versions list
// ------------------------------------------------------
exports.getVersions = async (req, res) => {
  try {
    const scheduleId = req.params.id;

    const rows = await sql`
      SELECT id, version, created_at, created_by
      FROM schedule_history
      WHERE schedule_id = ${scheduleId}
      ORDER BY version ASC
    `;

    res.json(rows);
  } catch (err) {
    console.error("Get versions error:", err);
    res.status(500).json({ error: "Failed to fetch versions" });
  }
};
