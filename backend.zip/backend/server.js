// server.js
const express = require("express");
const cors = require("cors");
const http = require("http");
require("dotenv").config();
const { startYjsServer } = require("./yjsServer.js");

// 🧩 Import routes
const facultyRoutes = require("./routes/facultyRoutes");
const studentRoutes = require("./routes/studentRoutes");
const authRoutes = require("./routes/authRoutes");
const reportRoutes = require("./routes/reportRoutes");
const ruleRoutes = require("./routes/ruleRoutes");
const feedbackRoutes = require("./routes/feedbackRoutes");
const surveyRoutes = require("./routes/surveyRoutes");
const sectionRoutes = require("./routes/sectionRoutes");
const facultyCoursesRoutes = require("./routes/facultyCoursesRoutes");
const notificationRoutes = require("./routes/notificationRoutes");
const courseRoutes = require("./routes/courseRoutes");
const dropdownsRoutes = require("./routes/dropdownsRoutes");
const aiRoutes = require("./routes/aiRoutes");
const scheduleRoutes = require("./routes/scheduleRoutes");
const irregularRoutes = require("./routes/irregularRoutes");
const scheduleHistoryRoutes = require("./routes/scheduleHistoryRoutes");

// ⚙️ Define the port
const PORT = process.env.PORT || 5001;

// ⚙️ Initialize app and server
const app = express();
const server = http.createServer(app);

// 🧠 Start Yjs WebSocket server (for collaborative data sync)
startYjsServer(server);

// ✅ CORS setup
const allowedOrigins = [
  "http://localhost:5173", // for local development
  "https://smartschedulefrontend.onrender.com", // ✅ production frontend
];

app.use(
  cors({
    origin: function (origin, callback) {
      if (!origin || allowedOrigins.includes(origin)) {
        callback(null, true);
      } else {
        console.warn("❌ Blocked by CORS:", origin);
        callback(new Error("Not allowed by CORS"));
      }
    },
    methods: ["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
    credentials: true,
  })
);

// ✅ Body parser
app.use(express.json());

// 🧭 API routes
app.use("/api/faculty", facultyRoutes);
app.use("/api/students", studentRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/reports", reportRoutes);
app.use("/api/rules", ruleRoutes);
app.use("/api/feedback", feedbackRoutes);
app.use("/api/surveys", surveyRoutes);
app.use("/api/sections", sectionRoutes);
app.use("/api/faculty-courses", facultyCoursesRoutes);
app.use("/api/irregular", irregularRoutes);
app.use("/api/notifications", notificationRoutes);
app.use("/api/courses", courseRoutes);
app.use("/api/dropdowns", dropdownsRoutes);
app.use("/api/ai", aiRoutes);
app.use("/api/schedules", scheduleRoutes);
app.use("/api/schedule-history", scheduleHistoryRoutes);

// ✅ Handle unknown routes gracefully
app.get("/", (req, res) => {
  res.send("✅ SmartSchedule Backend is running successfully.");
});

// ✅ Port handling for both local & Render environments
const listener = server.listen(PORT, "0.0.0.0", () => {
  console.log(
    `🚀 SmartSchedule backend running on port ${listener.address().port}`
  );
});
